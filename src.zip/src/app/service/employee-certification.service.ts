import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EmployeeCertificationService {

  constructor() { }
}
