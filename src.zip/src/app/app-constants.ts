export class AppConstants {
  public static BASE_URL_API = 'http://localhost:8085';
}