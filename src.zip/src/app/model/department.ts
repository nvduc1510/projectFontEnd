/**
 * Định nghĩa cấu trúc dữ liệu cho một đối tượng Department 
 */
export interface Department {
    departmentId: BigInt;
    departmentName: String;
}
