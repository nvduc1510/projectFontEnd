/**
 * Interface chứ thông tin của Certification
 */
export interface Certification{
    certificationId : BigInt;
    certificationName : String;
}
