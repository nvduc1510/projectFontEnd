export interface EmployeeCertification{
    certificationId: number;
    certificationName: string;
    certificationStartDate: string;
    certificationEndDate: string;
    employeeCertificationScore: number;
}